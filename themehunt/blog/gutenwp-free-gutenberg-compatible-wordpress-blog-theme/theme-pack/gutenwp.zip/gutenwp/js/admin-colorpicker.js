jQuery(document).ready(function($){
    $('.gutenwp-color-picker').wpColorPicker();
});